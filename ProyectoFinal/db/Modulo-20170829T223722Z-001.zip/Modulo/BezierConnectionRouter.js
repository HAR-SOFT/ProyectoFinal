/* This notice must be untouched at all times.

FreeGroup Draw2D 0.9.31
The latest version is available at
${draw2d.website}

Copyright (c) 2006 Andreas Herz. All rights reserved.
Created 5. 11. 2006 by Andreas Herz (Web: http://www.freegroup.de )

LICENSE: LGPL

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License (LGPL) as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA,
or see http://www.gnu.org/copyleft/lesser.html
*/

/**
 * @class Routes a {@link draw2d.Connection}, possibly using a constraint.
 *
 * @version 0.9.31
 * @author Andreas Herz
 * @constructor
 */
draw2d.BezierConnectionRouter=function(/*:boolean*/ noCheapRouter)
{
   if(!noCheapRouter)
      this.cheapRouter = new draw2d.ManhattanConnectionRouter();
   else
      this.cheapRouter=null;
   this.iteration=5;
};

draw2d.BezierConnectionRouter.prototype = new draw2d.ConnectionRouter();
draw2d.BezierConnectionRouter.prototype.type="draw2d.BezierConnectionRouter";


draw2d.BezierConnectionRouter.prototype.drawBezier=function(/*:Array*/pointArray,/*:Array*/resultArray, /*:float*/t, /*:int*/iter)
{
  var n = pointArray.length-1;

  var q = [];
  var n_plus_1= n+1;
  for (var i = 0; i < n_plus_1; i++)
  {
    q[i]=[];
    q[i][0] = pointArray[i];
  }

  for (var j = 1; j <= n; j++)
  {
    for (var i = 0; i <= (n-j); i++)
    {
      q[i][j] = new draw2d.Point((1 - t) * q[i][j - 1].x + t * q[i + 1][j - 1].x,
                          (1 - t) * q[i][j - 1].y + t * q[i + 1][j - 1].y);
    }
  }
    //Arrays für die Punkte der geteilten Kontrollpolygone C1, C2)
    var c1 = [];
    var c2 = [];

    for (var i=0;i<n+1;i++)
    {
      c1[i] = q[0][i];
      c2[i] = q[i][n-i];
    }

    if(iter>=0)
    {
      this.drawBezier(c1,resultArray, t, --iter);
      this.drawBezier(c2,resultArray, t, --iter);
    }
    else
    {
      for (var i=0;i<n;i++)
      {
        resultArray.push(q[i][n-i]);
      }
   }
};

/**
 * @see draw2d.ConnectionRouter#route(Connection)
 */
draw2d.BezierConnectionRouter.prototype.route=function(/*:draw2d.Connection*/ conn)
{
   if(this.cheapRouter!==null && (conn.getSource().getParent().isMoving===true || conn.getTarget().getParent().isMoving===true ))
   {
     this.cheapRouter.route(conn);
     return;
   }

   var pointList = [];
   var fromPt  = conn.getStartPoint();
   var toPt    = conn.getEndPoint();

   // create the Manhattan line stroke
   //
   this._route(pointList, conn, toPt, this.getEndDirection(conn), fromPt, this.getStartDirection(conn));
   var resultList = [];
   // create the Bezier spline from the ManhattanLineStroke
   //
   this.drawBezier(pointList,resultList, 0.5, this.iteration);
   for(var i=0;i<resultList.length;i++)
   {
     conn.addPoint(resultList[i]);
   }
   conn.addPoint(toPt);
};

/**
 * @private
 **/
draw2d.BezierConnectionRouter.prototype._route=function(pointList, /*:draw2d.Connection*/ conn,/*:draw2d.Point*/ fromPt, /*:int*/fromDir, /*:draw2d.Point*/toPt, /*:int*/toDir)
{
   var TOL     = 0.1;
   var TOLxTOL = 0.01;
   var MINDIST = 90;

   // fromPt is an x,y to start from.  
   // fromDir is an angle that the first link must 
   //
   var UP   = 0;
   var RIGHT= 1;
   var DOWN = 2;
   var LEFT = 3;

   var xDiff = fromPt.x - toPt.x;
   var yDiff = fromPt.y - toPt.y;
   var point;
   var dir;

   if (((xDiff * xDiff) < (TOLxTOL)) && ((yDiff * yDiff) < (TOLxTOL))) 
   {
      pointList.push(new draw2d.Point(toPt.x, toPt.y));
      return;
   }

   if (fromDir === LEFT)
   {
      if ((xDiff > 0) && ((yDiff * yDiff) < TOL) && (toDir === RIGHT))
      {
         point = toPt;
         dir = toDir;
      }
      else
      {
         if (xDiff < 0) 
         {
            point = new draw2d.Point(fromPt.x - MINDIST, fromPt.y);
         }
         else if (((yDiff > 0) && (toDir === DOWN)) || ((yDiff < 0) && (toDir === UP))) 
         {
            point = new draw2d.Point(toPt.x, fromPt.y);
         }
         else if (fromDir === toDir)
         {
            var pos = Math.min(fromPt.x, toPt.x) - MINDIST;
            point = new draw2d.Point(pos, fromPt.y);
         }
         else
         {
            point = new draw2d.Point(fromPt.x - (xDiff / 2), fromPt.y);
         }

         if (yDiff > 0) 
         {
            dir = UP;
         }
         else
         {
            dir = DOWN;
         }
      }
   }
   else if (fromDir === RIGHT)
   {
      if ((xDiff < 0) && ((yDiff * yDiff) < TOL)&& (toDir == LEFT)) 
      {
         point = toPt;
         dir = toDir;
      } 
      else 
      {
         if (xDiff > 0) 
         {
           point = new draw2d.Point(fromPt.x + MINDIST, fromPt.y);
         } 
         else if (((yDiff > 0) && (toDir === DOWN)) || ((yDiff < 0) && (toDir === UP))) 
         {
            point = new draw2d.Point(toPt.x, fromPt.y);
         } 
         else if (fromDir === toDir) 
         {
            var pos = Math.max(fromPt.x, toPt.x) + MINDIST;
            point = new draw2d.Point(pos, fromPt.y);
         } 
         else 
         {
               point = new draw2d.Point(fromPt.x - (xDiff / 2), fromPt.y);
         }

         if (yDiff > 0) 
            dir = UP;
         else
            dir = DOWN;
      }
   } 
   else if (fromDir === DOWN) 
   {
      if (((xDiff * xDiff) < TOL) && (yDiff < 0)&& (toDir === UP)) 
      {
         point = toPt;
         dir = toDir;
      } 
      else 
      {
         if (yDiff > 0) 
         {
            point = new draw2d.Point(fromPt.x, fromPt.y + MINDIST);
         } 
         else if (((xDiff > 0) && (toDir === RIGHT)) || ((xDiff < 0) && (toDir === LEFT))) 
         {
           point = new draw2d.Point(fromPt.x, toPt.y);
         } 
         else if (fromDir === toDir) 
         {
            var pos = Math.max(fromPt.y, toPt.y) + MINDIST;
            point = new draw2d.Point(fromPt.x, pos);
         } 
         else 
         {
            point = new draw2d.Point(fromPt.x, fromPt.y - (yDiff / 2));
         }

         if (xDiff > 0) 
            dir = LEFT;
         else 
            dir = RIGHT;
      }
   } 
   else if (fromDir === UP)
   {
      if (((xDiff * xDiff) < TOL) && (yDiff > 0) && (toDir === DOWN)) 
      {
         point = toPt;
         dir = toDir;
      }
      else
      {
         if (yDiff < 0) 
         {
            point = new draw2d.Point(fromPt.x, fromPt.y - MINDIST);
         } 
         else if (((xDiff > 0) && (toDir === RIGHT)) || ((xDiff < 0) && (toDir === LEFT))) 
         {
            point = new draw2d.Point(fromPt.x, toPt.y);
         } 
         else if (fromDir === toDir) 
         {
            var pos = Math.min(fromPt.y, toPt.y) - MINDIST;
            point = new draw2d.Point(fromPt.x, pos);
         } 
         else 
         {
            point = new draw2d.Point(fromPt.x, fromPt.y - (yDiff / 2));
         }

         if (xDiff > 0)
            dir = LEFT;
         else
            dir = RIGHT;
      }
   }
   this._route(pointList, conn,point, dir, toPt, toDir);
   pointList.push(fromPt);
}