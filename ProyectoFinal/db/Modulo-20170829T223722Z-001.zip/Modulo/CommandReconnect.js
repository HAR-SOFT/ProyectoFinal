/* This notice must be untouched at all times.

FreeGroup Draw2D 0.9.31
The latest version is available at
${draw2d.website}

Copyright (c) 2006 Andreas Herz. All rights reserved.
Created 5. 11. 2006 by Andreas Herz (Web: http://www.freegroup.de )

LICENSE: LGPL

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License (LGPL) as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA,
or see http://www.gnu.org/copyleft/lesser.html
*/

/**
 * 
 * @version 0.9.31
 * @author Andreas Herz
 * @constructor
 */
draw2d.CommandReconnect=function(/*:draw2d.Connection*/ con)
{
   draw2d.Command.call(this,"reconnect connection");
   this.con      = con;
   this.oldSourcePort  = con.getSource();
   this.oldTargetPort  = con.getTarget();
   this.oldRouter      = con.getRouter();

   // cheap routing during drag&drop
   this.con.setRouter(new draw2d.NullConnectionRouter());
};

draw2d.CommandReconnect.prototype = new draw2d.Command();
/** @private **/
draw2d.CommandReconnect.prototype.type="draw2d.CommandReconnect";

/**
 * Returns [true] if the command can be execute and the execution of the
 * command modify the model. A CommandMove with [startX,startX] == [endX,endY] should
 * return false. <br>
 * the execution of the Command doesn't modify the model.
 *
 * @type boolean
 **/
draw2d.CommandReconnect.prototype.canExecute=function()
{
  // return false if we doesn't modify the model => NOP Command
  return true;
};

draw2d.CommandReconnect.prototype.setNewPorts=function(/*:draw2d.Port*/ source, /*:draw2d.Port*/ target)
{
  this.newSourcePort = source;
  this.newTargetPort = target;
};

/**
 * Execute the command the first time
 * 
 **/
draw2d.CommandReconnect.prototype.execute=function()
{
   this.redo();
};

/**
 * Execute the command the first time
 * 
 **/
draw2d.CommandReconnect.prototype.cancel=function()
{
   var start  = this.con.sourceAnchor.getLocation(this.con.targetAnchor.getReferencePoint());
   var end    = this.con.targetAnchor.getLocation(this.con.sourceAnchor.getReferencePoint());
   this.con.setStartPoint(start.x,start.y);
   this.con.setEndPoint(end.x,end.y);
   this.con.getWorkflow().showLineResizeHandles(this.con);
   this.con.setRouter(this.oldRouter);
};

/**
 * Undo the command
 *
 **/
draw2d.CommandReconnect.prototype.undo=function()
{
  this.con.setSource(this.oldSourcePort);
  this.con.setTarget(this.oldTargetPort);
  this.con.setRouter(this.oldRouter);
  if(this.con.getWorkflow().getCurrentSelection()==this.con)
     this.con.getWorkflow().showLineResizeHandles(this.con);
};

/** 
 * Redo the command after the user has undo this command
 *
 **/
draw2d.CommandReconnect.prototype.redo=function()
{
  this.con.setSource(this.newSourcePort);
  this.con.setTarget(this.newTargetPort);
  this.con.setRouter(this.oldRouter);
  if(this.con.getWorkflow().getCurrentSelection()==this.con)
     this.con.getWorkflow().showLineResizeHandles(this.con);
};
